document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector(".form-transaccion");
    const mensaje = document.createElement("p");
    mensaje.style.marginTop = "10px";
    
    form.appendChild(mensaje);

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        const formData = new FormData(form);

        fetch("../php/add.php", {
            method: "POST",
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mensaje.textContent = "✅ Transación guardada correctamente.";
                mensaje.style.color = "green";
                form.reset();
            } else {
                mensaje.textContent = "❌ Error al guardar la transación.";
                mensaje.style.color = "red";
            }
        })
        .catch(error => {
            mensaje.textContent = "❌ Error de conexión.";
            mensaje.style.color = "red";
        });
    });
});
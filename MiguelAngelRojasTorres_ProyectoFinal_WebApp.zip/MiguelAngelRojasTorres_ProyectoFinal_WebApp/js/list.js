
document.addEventListener("DOMContentLoaded", () => {
  
    const tablaBody = document.querySelector("#tablaTransacciones tbody");

    if (tablaBody) {
      cargarTransacciones();
    }
  });
  
  function cargarTransacciones() {
    fetch("../php/list.php")
      .then(response => response.json())
      .then(data => {
        const tablaBody = document.querySelector("#tablaTransacciones tbody");
        const campoBalance = document.querySelector("#tablaBalance tbody");
        let suma = 0;
        tablaBody.innerHTML = "";
  
        data.forEach((transaccion) => {
          const filaTransaccion = document.createElement("tr");
  
          const tdFecha = document.createElement("td");
          tdFecha.textContent = transaccion.fecha;
          filaTransaccion.appendChild(tdFecha);
  
          const tdCat = document.createElement("td");
          tdCat.textContent = transaccion.categoria;
          filaTransaccion.appendChild(tdCat);
          
          const tdTip = document.createElement("td");
          tdTip.textContent = transaccion.tipo;
          filaTransaccion.appendChild(tdTip);

          const tdMonto = document.createElement("td");
          tdMonto.textContent = transaccion.monto;
          filaTransaccion.appendChild(tdMonto);
  
          const tdDesc = document.createElement("td");
          tdDesc.textContent = transaccion.descripcion || "";
          filaTransaccion.appendChild(tdDesc);
  
          tablaBody.appendChild(filaTransaccion);

          if (transaccion.tipo == "Ingreso"){
            suma += Number(transaccion.monto) * 100;
          }

          else{
            suma -= Number(transaccion.monto) * 100;
          }
          
        });

      campoBalance.innerHTML = suma / 100;

      if (suma > 0){
        campoBalance.style.color = "green";
      }
      
      else{
        campoBalance.style.color = "red";
      }

      })
      .catch(error => console.error("Error al cargar transacciones:", error));
  }
  
<?php
require_once 'db.php';
header('Content-Type: application/json; charset=utf-8');
$sql = "SELECT fecha, categoria, monto, tipo, descripcion FROM transactions ORDER BY fecha DESC";
$result = $conn->query($sql);
$data = array();

while($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$conn->close();
echo json_encode($data);
?>
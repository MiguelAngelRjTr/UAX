<?php
require_once 'db.php';
$response = ["success" => false];
$fecha       = $_POST['fecha'];
$categoria   = $_POST['categoria'];
$monto       = $_POST['monto'];
$tipo        = $_POST['tipo'];
$descripcion = $_POST['descripcion'] ?? '';

$stmt = $conn->prepare("INSERT INTO transactions (fecha, categoria, monto, tipo, descripcion) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssdss", $fecha, $categoria, $monto, $tipo, $descripcion);

if ($stmt->execute()) {
    
    $response["success"] = true;
} else {
    
    $response["success"] = false;
}

$stmt->close();
$conn->close();

header('Content-Type: application/json; charset=utf-8');

echo json_encode($response);

exit;
?>